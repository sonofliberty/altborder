# AltBorder: Own World

Selected option F.

SVG logos and flag symbols are in svg/. PNG logos and app icons are in png/. Open preview.html to view the set. All lettering is stored as paths; no font installation is required.

Use the light logo on dark surfaces and the dark logo on light surfaces. Forest-green and white one-color versions are supplied. Keep the aspect ratio. Use the flag alone below 138px total logo width.

Colors: orange #ff7a14; forest green #123f29; cream #faf6e9.

The chosen concept was generated with ImageGen, then traced into smooth, flat SVG geometry. The fine edge highlight was removed for clarity at small sizes. See PROJECT-NOTES.md for project source paths and build details.
